package com.a0000007.intro.service;

public class IntroServiceImpl implements IntroService {

}
