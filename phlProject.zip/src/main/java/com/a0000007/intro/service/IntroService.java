package com.a0000007.intro.service;

public interface IntroService {

}
