package com.a0000007.intro.dao;

import com.a0000007.intro.service.IntroServiceImpl;

public class IntroDAO extends IntroServiceImpl {

}
