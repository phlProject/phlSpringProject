package com.a0000007.counsel.service;

public interface CounselService {

}
