package com.a0000007.counsel.dao;

import org.springframework.stereotype.Repository;

import com.phl.dao.AbstractDAO;

@Repository("/a0000007/counselDAO")
public class CounselDAO extends AbstractDAO {

}
