package com.a0000007.program.service;

public interface ProgramService {

}
