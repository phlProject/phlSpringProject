package com.a0000007.program.dao;

import org.springframework.stereotype.Repository;

import com.phl.dao.AbstractDAO;

@Repository("/a0000007/programDAO")
public class ProgramDAO extends AbstractDAO {

}
