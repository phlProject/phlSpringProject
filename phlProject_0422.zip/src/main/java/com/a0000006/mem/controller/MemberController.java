package com.a0000006.mem.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.a0000006.mem.service.MemberService;
import com.phl.common.CommandMap;
import com.phl.common.service.PhlCommService;

@Controller
public class MemberController {

	Logger log = Logger.getLogger(this.getClass());
	
	@Resource(name="memberService")
	private MemberService memberService;
	
	/* 공통 */
	@Resource(name="phlCommService")
	private PhlCommService phlCommService;
	
	/* 로그인 폼 */
	@RequestMapping(value="/a0000006/mem/memLoginForm.do")
	public ModelAndView memLoginForm(CommandMap commandMap) throws Exception{
	    ModelAndView mv = new ModelAndView("/a0000006/member/memLoginForm");
	     
	    return mv;
	}
	
	/* 로그인 */
	@RequestMapping(value="/a0000006/mem/loginAction.do")
	public ModelAndView loginAction(CommandMap commandMap, HttpSession session, HttpServletRequest request) throws Exception{
        ModelAndView mv = new ModelAndView();
        
        
        commandMap.put("BSNS_CODE", session.getAttribute("BSNS_CODE"));
        
        String resultValue = "";
        
        /* 로그인(ID,PW CHECK) */
        List<Map<String,Object>> idPwChk = memberService.idPwCheck(commandMap.getMap());
        
        /* 해당하는 아이디 존재 시 */
        if(idPwChk.size() != 0){
        	String queryPw = (String) idPwChk.get(0).get("MEM_PW");
        	/* 해당하는 아이디, 비밀번호 일치 시 */
	        if(queryPw != null && queryPw.equals(commandMap.get("mem_pw"))){
	        	resultValue = "SUCCESS";
	        	/* 로그인 정보 */
	        	List<Map<String,Object>> loginInfo = memberService.loginInfo(commandMap.getMap());
	
	        	session.setAttribute("loginInfo", loginInfo.get(0));
	        	session.setAttribute("session_id", loginInfo.get(0).get("MEM_ID"));
	        	
	        	mv.setViewName("/a0000006/mainIndex");
	        }else{
	        	/* 비밀번호 오류 */
	        	resultValue = "PW_ERROR";
	        	
	        	mv.setViewName("/a0000006/member/memLoginForm");
	        }
        }else{
        	/* 아이디 오류 */
        	resultValue = "ID_ERROR";
        	mv.setViewName("/a0000006/member/memLoginForm");
        }
        mv.addObject("resultValue",resultValue);  

        return mv;
    }
	
	/* 마이페이지 */
	@RequestMapping(value="/a0000006/mem/memMyPage.do")
	public ModelAndView memMyPage(CommandMap commandMap, HttpSession session, HttpServletRequest request) throws Exception{
		ModelAndView mv = new ModelAndView("/a0000006/member/memMyPage");
	
		commandMap.put("SESSION_ID", session.getAttribute("session_id"));
		commandMap.put("BSNS_CODE", session.getAttribute("BSNS_CODE"));
	    commandMap.put("CL_CODE", "G01");
	    commandMap.put("NOT_DETAIL_CODE", "'998','999'");
	    
	    List<CommandMap> commList = phlCommService.selectCommCode(commandMap.getMap());
	    
		List<CommandMap> myPageInfo = memberService.memMyPage(commandMap.getMap());
		
		mv.addObject("commList", commList);
		mv.addObject("myPageInfo", myPageInfo.get(0)); 
		
		return mv;
	}
	
	/* 로그아웃 */
	@RequestMapping(value="/a0000006/mem/logoutAction.do")
	public ModelAndView logoutAction(CommandMap commandMap, HttpSession session, HttpServletRequest request) throws Exception{
        ModelAndView mv = new ModelAndView("/a0000006/mainIndex");
        
        /* 로그인정보만 세션제거 */
        session.removeAttribute("loginInfo");
        session.removeAttribute("session_id");
        
        return mv;
    }
	
	/* 회원가입 폼 */
	@RequestMapping(value="/a0000006/mem/memRegistForm.do")
	public ModelAndView memRegistForm(CommandMap commandMap, HttpSession session, HttpServletRequest request) throws Exception{
	    ModelAndView mv = new ModelAndView("/a0000006/member/memRegistForm");
	    
	    commandMap.put("BSNS_CODE", session.getAttribute("BSNS_CODE"));
	    commandMap.put("CL_CODE", "G01");
	    commandMap.put("NOT_DETAIL_CODE", "'998','999'");
	    
	    
	    List<CommandMap> commList = phlCommService.selectCommCode(commandMap.getMap());
	    
	    mv.addObject("commList", commList);
	    
	    return mv;
	}

	/* 회원 등록 */
	@RequestMapping(value="/a0000006/mem/insertMemRegist.do")
	public ModelAndView insertMemRegist(CommandMap commandMap, HttpSession session, HttpServletRequest request) throws Exception{
		ModelAndView mv = new ModelAndView("jsonView");
		
		commandMap.put("BSNS_CODE", session.getAttribute("BSNS_CODE"));

		String result = memberService.insertMemRegist(commandMap.getMap());
		
		mv.addObject("result", result);  		
		
		return mv;
	}
	
	/* 마이페이지 수정 */
	@RequestMapping(value="/a0000006/mem/updateMemRegist.do")
	public ModelAndView updateMemRegist(CommandMap commandMap) throws Exception{
		ModelAndView mv = new ModelAndView("/a0000006/mainIndex");
		
		memberService.updateMemRegist(commandMap.getMap());
		
		return mv;
	}
	
	/* 회원탈퇴 */
	@RequestMapping(value="/a0000006/mem/deleteMemRegist.do")
	public ModelAndView deleteMemRegist(CommandMap commandMap, HttpSession session, HttpServletRequest request) throws Exception{
		ModelAndView mv = new ModelAndView("/a0000006/mainIndex");
		
		memberService.deleteMemRegist(commandMap.getMap());
		
		/* 로그인정보만 세션제거 */
        session.removeAttribute("loginInfo");
        session.removeAttribute("session_id");
		
        return mv;
	}
	
	/* 아이디 중복체크 */
	@RequestMapping(value="/a0000006/mem/idDupChk.do")
	public ModelAndView idDupChk(CommandMap commandMap, HttpSession session, HttpServletRequest request) throws Exception{
		
		ModelAndView mv = new ModelAndView("jsonView");
		commandMap.put("BSNS_CODE", session.getAttribute("BSNS_CODE"));
		
		int id_Chk = memberService.idDupChk(commandMap.getMap());
		String result = "";
		
		if(id_Chk == 0){
			result = "success";
		}else{
			result = "fail";
		}
		
		mv.addObject("result", result);  		
		return mv;
	}
	
	/* 회원리스트 */
	@RequestMapping(value="/a0000006/mem/selectMemList.do")
	public ModelAndView selectMemList(CommandMap commandMap) throws Exception{
        ModelAndView mv = new ModelAndView("/a0000006/member/memberList");
         
        List<Map<String,Object>> list = memberService.selectMemList(commandMap.getMap());
        mv.addObject("list", list);
        return mv;
    }
	
}
